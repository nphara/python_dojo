# Python Packaging Study

This project is a practice of python packaging.

## Reference

[Python Packaging User Guide](https://packaging.python.org/en/latest/tutorials/packaging-projects/)
